
function inventoryRealRemoveAll()
{
	var table = window.document.getElementById("inventoryReal_tbl");
    var rowNum = table.rows.length;
	if(rowNum > 0) {
		for(i=0;i<rowNum;i++) {
			table.deleteRow(i);
			rowNum = rowNum-1;
			i = i-1;
		}
	}
}

function inventoryRealAddItem(epc, pc, nums, rssi, feq)
{
	var table = window.document.getElementById("inventoryReal_tbl");
	var row = table.insertRow(table.rows.length);
    var obj = row.insertCell(0);
	obj.width = "20px"; obj.className = "tc";
    obj.innerHTML = table.rows.length;
	obj = row.insertCell(1);
	obj.width = "150px"; obj.className = "tc";
    obj.innerHTML = epc;
	obj = row.insertCell(2);
	obj.width = "50px"; obj.className = "tc";
    obj.innerHTML = pc;
	obj = row.insertCell(3);
	obj.width = "20px"; obj.className = "tc";
    obj.innerHTML = nums;
	obj = row.insertCell(4);
	obj.width = "20px"; obj.className = "tc";
    obj.innerHTML = rssi;
	obj = row.insertCell(5);
	obj.width = "20px"; obj.className = "tc";
    obj.innerHTML = feq;
}


function inventoryBufferRemoveAll()
{
	var table = window.document.getElementById("inventoryBuffer_tbl");
    var rowNum = table.rows.length;
	if(rowNum > 0) {
		for(i=0;i<rowNum;i++) {
			table.deleteRow(i);
			rowNum = rowNum-1;
			i = i-1;
		}
	}
}

function inventoryBufferAddItem(pc, crc, epc, ant, rssi, nums)
{
	var table = window.document.getElementById("inventoryBuffer_tbl");
	var row = table.insertRow(table.rows.length);
    var obj = row.insertCell(0);
	obj.width = "20px"; obj.className = "tc";
    obj.innerHTML = table.rows.length;
	obj = row.insertCell(1);
	obj.width = "40px"; obj.className = "tc";
    obj.innerHTML = pc;
	obj = row.insertCell(2);
	obj.width = "40px"; obj.className = "tc";
    obj.innerHTML = crc;
	obj = row.insertCell(3);
	obj.width = "150px"; obj.className = "tc";
    obj.innerHTML = epc;
	obj = row.insertCell(4);
	obj.width = "20px"; obj.className = "tc";
    obj.innerHTML = ant;
	obj = row.insertCell(5);
	obj.width = "20px"; obj.className = "tc";
    obj.innerHTML = rssi;
	obj = row.insertCell(6);
	obj.width = "30px"; obj.className = "tc";
    obj.innerHTML = nums;
}


function fastSwitchRemoveAll()
{
	var table = window.document.getElementById("fastSwitch_tbl");
    var rowNum = table.rows.length;
	if(rowNum > 0) {
		for(i=0;i<rowNum;i++) {
			table.deleteRow(i);
			rowNum = rowNum-1;
			i = i-1;
		}
	}
}

function fastSwitchAddItem(epc, pc, ant, rssi, feq)
{
	var table = window.document.getElementById("fastSwitch_tbl");
	var row = table.insertRow(table.rows.length);
    var obj = row.insertCell(0);
	obj.width = "20px"; obj.className = "tc";
    obj.innerHTML = table.rows.length;
	obj = row.insertCell(1);
	obj.width = "150px"; obj.className = "tc";
    obj.innerHTML = epc;
	obj = row.insertCell(2);
	obj.width = "40px"; obj.className = "tc";
    obj.innerHTML = pc;
	obj = row.insertCell(3);
	obj.width = "70px"; obj.className = "tc";
    obj.innerHTML = ant;
	obj = row.insertCell(4);
	obj.width = "20px"; obj.className = "tc";
    obj.innerHTML = rssi;
	obj = row.insertCell(5);
	obj.width = "30px"; obj.className = "tc";
    obj.innerHTML = feq;
}


function operateTagRemoveAll()
{
	var table = window.document.getElementById("operateTag_tbl");
    var rowNum = table.rows.length;
	if(rowNum > 0) {
		for(i=0;i<rowNum;i++) {
			table.deleteRow(i);
			rowNum = rowNum-1;
			i = i-1;
		}
	}
}

function operateTagAddItem(pc, crc, epc, data, len, ant, nums)
{
	var table = window.document.getElementById("operateTag_tbl");
	var row = table.insertRow(table.rows.length);
    var obj = row.insertCell(0);
	obj.width = "20px"; obj.className = "tc";
    obj.innerHTML = table.rows.length;
	obj = row.insertCell(1);
	obj.width = "40px"; obj.className = "tc";
    obj.innerHTML = pc;
	obj = row.insertCell(2);
	obj.width = "40px"; obj.className = "tc";
    obj.innerHTML = crc;
	obj = row.insertCell(3);
	obj.width = "150px"; obj.className = "tc";
    obj.innerHTML = epc;
	obj = row.insertCell(4);
	obj.width = "150px"; obj.className = "tc";
    obj.innerHTML = data;
	obj = row.insertCell(5);
	obj.width = "40px"; obj.className = "tc";
    obj.innerHTML = len;
	obj = row.insertCell(6);
	obj.width = "20px"; obj.className = "tc";
    obj.innerHTML = ant;
	obj = row.insertCell(7);
	obj.width = "40px"; obj.className = "tc";
    obj.innerHTML = nums;
}


function inventory6BRemoveAll()
{
	var table = window.document.getElementById("inventory6B_tbl");
    var rowNum = table.rows.length;
	if(rowNum > 0) {
		for(i=0;i<rowNum;i++) {
			table.deleteRow(i);
			rowNum = rowNum-1;
			i = i-1;
		}
	}
}

function inventory6BAddItem(uid, ant, nums)
{
	var table = window.document.getElementById("inventory6B_tbl");
	var row = table.insertRow(table.rows.length);
    var obj = row.insertCell(0);
	obj.width = "20px"; obj.className = "tc";
    obj.innerHTML = table.rows.length;
	obj = row.insertCell(1);
	obj.width = "200px"; obj.className = "tc";
    obj.innerHTML = uid;
	obj = row.insertCell(2);
	obj.width = "40px"; obj.className = "tc";
    obj.innerHTML = ant;
	obj = row.insertCell(3);
	obj.width = "40px"; obj.className = "tc";
    obj.innerHTML = nums;
}


function monitorRemoveAll()
{
	var table = window.document.getElementById("monitor_tbl");
    var rowNum = table.rows.length;
	if(rowNum > 0) {
		for(i=0;i<rowNum;i++) {
			table.deleteRow(i);
			rowNum = rowNum-1;
			i = i-1;
		}
	}
}

function monitorAddItem(bSend, strData)
{
	var table = window.document.getElementById("monitor_tbl");
	var row = table.insertRow(table.rows.length);
    var obj = row.insertCell(0);
	//obj.className = "tc";
	if( bSend ) {
		obj.style.color = "#0000FF";
	} else {
		obj.style.color = "#FF0000";
	}
    obj.innerHTML = strData;
	
	obj = window.document.getElementById("div_monitor_tbl");
	obj.scrollTop = obj.scrollHeight;
}

function logRemoveAll()
{
	var table = window.document.getElementById("log_tbl");
    var rowNum = table.rows.length;
	if(rowNum > 0) {
		for(i=0;i<rowNum;i++) {
			table.deleteRow(i);
			rowNum = rowNum-1;
			i = i-1;
		}
	}
}

function logAddItem(bSuccess,strLog)
{
	var table = window.document.getElementById("log_tbl");
	var row = table.insertRow(table.rows.length);
    var obj = row.insertCell(0);	
    if( !bSuccess ) {
		obj.style.color = "#FF0000";
	}
    obj.innerHTML = strLog;
	
	obj = window.document.getElementById("div_log_tbl");
	obj.scrollTop = obj.scrollHeight;
}

