
var VAL_SET_TIMEOUT = 1000;

	
var INVENTORY_ERR = 0x00;
var INVENTORY_ERR_END = 0x01;
var INVENTORY_END = 0x02;
var WRITE_LOG = 0x10;
var REFRESH_READER_SETTING = 0x11;
var REFRESH_INVENTORY = 0x12;
var REFRESH_INVENTORY_REAL = 0x13;
var REFRESH_FAST_SWITCH = 0x14;
var REFRESH_OPERATE_TAG = 0x15;
var REFRESH_ISO18000_6B = 0x15;

/* �������б� */
var CMD_RESET = 0x70;
var CMD_SET_UART_BAUDRATE = 0x71;
var CMD_GET_FIRMWARE_VERSION = 0x72;
var CMD_SET_READER_ADDRESS = 0x73;
var CMD_SET_WORK_ANTENNA = 0x74;
var CMD_GET_WORK_ANTENNA = 0x75;
var CMD_SET_OUTPUT_POWER = 0x76;
var CMD_GET_OUTPUT_POWER = 0x77;
var CMD_SET_FREQUENCY_REGION = 0x78;
var CMD_GET_FREQUENCY_REGION = 0x79;
var CMD_SET_BEEPER_MODE = 0x7A;
var CMD_GET_READER_TEMPERATURE = 0x7B;
var CMD_READ_GPIO_VALUE = 0x60;
var CMD_WRITE_GPIO_VALUE = 0x61;
var CMD_SET_ANT_CONNECTION_DETECTOR = 0x62;
var CMD_GET_ANT_CONNECTION_DETECTOR = 0x63;
var CMD_SET_TEMPORARY_OUTPUT_POWER = 0x66;
var CMD_SET_READER_IDENTIFIER = 0x67;
var CMD_GET_READER_IDENTIFIER = 0x68;
var CMD_SET_RF_LINK_PROFILE = 0x69;
var CMD_GET_RF_LINK_PROFILE = 0x6A;
var CMD_GET_RF_PORT_RETURN_LOSS = 0x7E;
var CMD_INVENTORY = 0x80;
var CMD_READ_TAG = 0x81;
var CMD_WRITE_TAG = 0x82;
var CMD_LOCK_TAG = 0x83;
var CMD_KILL_TAG = 0x84;
var CMD_SET_ACCESS_EPC_MATCH = 0x85;
var CMD_GET_ACCESS_EPC_MATCH = 0x86;
var CMD_REAL_TIME_INVENTORY = 0x89;
var CMD_FAST_SWITCH_ANT_INVENTORY = 0x8A;
var CMD_CUSTOMIZED_SESSION_TARGET_INVENTORY = 0x8B;
var CMD_SET_IMPINJ_FAST_TID = 0x8C;
var CMD_SET_AND_SAVE_IMPINJ_FAST_TID = 0x8D;
var CMD_GET_IMPINJ_FAST_TID = 0x8E;
var CMD_ISO18000_6B_INVENTORY = 0xB0;
var CMD_ISO18000_6B_READ_TAG = 0xB1;
var CMD_ISO18000_6B_WRITE_TAG = 0xB2;
var CMD_ISO18000_6B_LOCK_TAG = 0xB3;
var CMD_ISO18000_6B_QUERY_LOCK_TAG = 0xB4;
var CMD_GET_INVENTORY_BUFFER =  0x90;
var CMD_GET_AND_RESET_INVENTORY_BUFFER = 0x91;
var CMD_GET_INVENTORY_BUFFER_TAG_COUNT = 0x92;
var CMD_RESET_INVENTORY_BUFFER = 0x93;

/* ���ܴ�������applet�ڲ����� */
var ERROR_SUCCESS = 0x10;
var ERROR_FAIL = 0x11;

var UHF;
var DOC;
var mReader;
var mReaderHelper;
var m_curReaderSetting;
var m_curInventoryBuffer;
var m_curOperateTagBuffer;
var m_curOperateTagISO18000Buffer;

var timer;
var timerInventoryReal;
var timerFastSwitch;
var timerInventoryReal6B;

function checkHexInput(inputString)
{
	var flag = false;
	//var reg = new RegExp("[a-fA-F0-9.\s]+");
	if ( inputString.match(/[a-fA-F0-9.\s]+/) ) {
		flag = true;
	}
	return flag;
}

function tryGetCheck(obj)
{
	if( obj.id == 'text_MonitorWriteData' ) {
		var szWriteData = DOC.getElementById("text_MonitorWriteData").value;
		var btAryWriteData = stringToByteArray(szWriteData);
		
		if( btAryWriteData.length > 1 ) {
			var btCheckSum = checkSum( btAryWriteData, 0, btAryWriteData.length );
			var szCheckSum = '0' + btCheckSum.toString(16).toUpperCase();
			szCheckSum = szCheckSum.substring( szCheckSum.length - 2 );
			DOC.getElementById("text_MonitorWriteDataCheck").value = "0x" + szCheckSum;
		}
	}
}


function hexInputOnKeyUp(oEvent,obj)
{
	var inputStr = String.fromCharCode(oEvent.keyCode);
	if (oEvent.keyCode != 8)
	{
		obj.value = obj.value.replace(/[^0-9a-fA-F\n\s]/g,"");
		obj.value = obj.value.toUpperCase();
	}
	else
	{
		var nIndex = obj.selectionStart;
		if (nIndex > 0) {
			if (obj.value.charAt(nIndex - 1) == ' ')
			{
				obj.value = obj.value.substring(0, nIndex - 1);
				obj.selectionStart = nIndex - 1;
			}
		}
	}
	
	tryGetCheck(obj);
}

function hexInputChange(obj)
{
	var nIndex = obj.selectionStart;
	if (nIndex > 1)
	{
		if (nIndex > 2 && obj.value.charAt(nIndex - 1) != ' ' && obj.value.charAt(nIndex - 2) != ' ' && obj.value.charAt(nIndex - 3) != ' ')
		{
			var strSub1 = obj.value.substr(0, nIndex - 1);
			var strSub2 = obj.value.substr(nIndex - 1);
			obj.value = strSub1 + " " + strSub2;
			obj.selectionStart = nIndex + 1;
		} else if ( obj.value.charAt(nIndex - 1) != ' ' && obj.value.charAt(nIndex - 2) != ' ') {
			var strSub1 = obj.value.substr(0, nIndex);
			var strSub2 = obj.value.substr(nIndex);
			obj.value = strSub1 + " " + strSub2;
			obj.selectionStart = nIndex + 1;
		}
	}
	
	tryGetCheck(obj);
}

function refreshSetPage()
{
	var inputList;
	
	if (DOC.getElementById("basicSet").style.display != "none") {
		inputList = DOC.getElementById("basicSet").getElementsByTagName("input");
	} else if ( DOC.getElementById("rfSet").style.display != "none" ){
		inputList = DOC.getElementById("rfSet").getElementsByTagName("input");
		DOC.getElementById("startRegionList").options.length = 0;
		DOC.getElementById("endRegionList").options.length = 0;
	}
	//�Ա��������е�input���б���
	for(var i=0; i<inputList.length && inputList[i]; i++) {
		//�ж��Ƿ�Ϊ��ť
		if(inputList[i].id != "tcpAddr" && inputList[i].id != "tcpPort")   
		{
			if (inputList[i].type == "text") {
				inputList[i].value = "";
			} else if (inputList[i].type == "radio") {
				inputList[i].checked = false;
			} else if (inputList[i].type == "radio") {
				inputList[i].checked = false;
			}
		}
	}
}

function refreshInventoryReal()
{
	inventoryRealRemoveAll();
}

function refreshInventoryBuffer()
{
	inventoryBufferRemoveAll();
}

function refreshFastSwitch()
{
	fastSwitchRemoveAll();
}

function refreshOperateTag()
{
	operateTagRemoveAll();
}

function refreshInventory6B()
{
	inventory6BRemoveAll();
}

function refreshMonitor()
{
	monitorRemoveAll();
}

function refresh()
{
	if(DOC.getElementById("basicSet").style.display != "none" | DOC.getElementById("rfSet").style.display != "none" ) {
		refreshSetPage();
	} else if( DOC.getElementById("inventoryReal").style.display != "none" ){
		refreshInventoryReal();
	} else if( DOC.getElementById("inventoryBuffer").style.display != "none" ){
		refreshInventoryBuffer();
	} else if( DOC.getElementById("fastSwitch").style.display != "none" ){
		refreshFastSwitch();
	} else if( DOC.getElementById("operateTag").style.display != "none" ){
		refreshOperateTag();
	} else if( DOC.getElementById("ISO180006B").style.display != "none" ){
		refreshInventory6B();
	} else if( DOC.getElementById("monitor").style.display != "none" ){
		refreshMonitor();
	}
}

function setTimeoutCall(id, t)
{
	if (timer) clearTimeout(timer);
	
	t = typeof(t) == 'undefined' ? VAL_SET_TIMEOUT : t;
	timer = setTimeout('onTimeout()', t);
	
	enabledAll(false);
}

function onTimeout()
{
	alert("������ʱ������!");
	enabledAll(true);
}

function onTimerInventoryReal()
{
	inventoryRealRemoveAll();
	
	for( var pos = 0 ; pos < m_curInventoryBuffer.lsTagList.size(); pos++ ) {
		var map = m_curInventoryBuffer.lsTagList.get(pos);
		inventoryRealAddItem( 
			map.strEPC, 
			map.strPC, 
			map.nReadCount.toString(10), 
			(parseInt(map.strRSSI) - 129).toString(10) + "dBm", 
			map.strFreq 
		);
	}
}

function onTimerFastSwitch()
{
	fastSwitchRemoveAll();
	
	for( var pos = 0 ; pos < m_curInventoryBuffer.lsTagList.size(); pos++ ) {
		var map = m_curInventoryBuffer.lsTagList.get(pos);
		fastSwitchAddItem( 
			map.strEPC, 
			map.strPC, 
			map.nAnt1.toString(10) + " / " + map.nAnt2.toString(10) + " / " + map.nAnt3.toString(10) + " / " + map.nAnt4.toString(10), 
			(parseInt(map.strRSSI) - 129).toString(10) + "dBm", 
			map.strFreq 
		);
	}
}

function onTimerInventoryReal6B()
{
	var  operateTagUid6BList = DOC.getElementById("operateTag6BUIDList");
	operateTagUid6BList.options.length = 0;
	
	inventory6BRemoveAll();
	
	for( var pos = 0 ; pos < m_curOperateTagISO18000Buffer.lsTagList.size(); pos++ ) {
		var map = m_curOperateTagISO18000Buffer.lsTagList.get(pos);
		inventory6BAddItem( 
			map.strUID, 
			map.btAntId.toString(10), 
			map.nTotal.toString(10)
		);
		operateTagUid6BList.options.add( new Option(map.strUID, pos));
	}
}

function isDisabledById(id)
{
	var obj = window.document.getElementById(id);
	if (obj) {
		return obj.disabled;
	} else {
		return false;
	}
}

function disabledById(id)
{
	var obj = window.document.getElementById(id);
	if (obj) {
		obj.disabled = true;
	}
}

function enabledById(id)
{
	var obj = window.document.getElementById(id);
	if (obj) {
		obj.disabled = false;
	}
}

function enabledAll(enable)
{
	var list;
	enable = typeof(enable) == 'undefined' ? true : enable;
	
	list = window.document.getElementsByTagName("input");
	//�Ա��������е�input���б���
	for(var i=0; i<list.length && list[i]; i++) {
		//�ж��Ƿ�Ϊ��ť
		if(list[i].type == "button" && list[i].disabled == enable && list[i].id != "btn_refresh")   
		{
			list[i].disabled = !enable;
		}
	}
	
	refreshConnectBtn();
}

/* ��ʼ��Setting */
function initSetting()
{
	DOC = window.document;
	UHF = DOC.uhf;

	UHF.setOnConnectCallback("onConnect");
	
	enabledAll(false);
	
    DOC.getElementById("set_ConnType_1").checked = true;
	DOC.getElementById("tcpAddr").value = getCookie("set_tcp_ip_host");
	DOC.getElementById("tcpPort").value = getCookie("set_tcp_ip_port");
	refreshConnectBtn();
}

function refreshConnectBtn()
{
    var type_1 = DOC.getElementById("set_ConnType_1").checked;
    var type_2 = DOC.getElementById("set_ConnType_2").checked;
    
    disabledById("btn_connect_rs232");
    disabledById("btn_disconnect_rs232");
    disabledById("btn_connect_tcp");
    disabledById("btn_disconnect_tcp");
    
	if (UHF.IsConnected()) {
        if( type_1 ) {
            enabledById("btn_disconnect_rs232");
        } else if ( type_2 ) {
            enabledById("btn_disconnect_tcp");
        }
	} else {
        if( type_1 ) {
            enabledById("btn_connect_rs232");
        } else if ( type_2 ) {
            enabledById("btn_connect_tcp");
        }
	}
}

/* ���ӻص����� */
function onConnect(code)
{
	if (code != UHF.CONNECTING) {
		refreshConnectBtn();
	}

	switch (code)
	{
	case UHF.TCP_IP_ERROR_HOST:
		alert("IP��ַ��ʽ����!");
		break;
	case UHF.CONNECTING:
		//alert("��������!");
		break;
	case UHF.CONNECT_TIMEOUT:
		alert("���ӳ�ʱ!");
		break;
	case UHF.CONNECT_FAIL:
		alert("����ʧ��!");
		break;
	case UHF.CONNECT_SUCCESS:
		alert("���ӳɹ�!");
		mReader = UHF.getReader();
		mReaderHelper = UHF.getReaderHelper();
		mReaderHelper.setOnLogCallback("onLog");
		mReaderHelper.setOnRefreshSetCallback("onRefreshSet");
		mReaderHelper.setOnRefreshInventoryCallback("onRefreshInventory");
		mReaderHelper.setOnRefreshInventoryRealCallback("onRefreshInventoryReal");
		mReaderHelper.setOnRefreshFastSwitchCallback("onRefreshFastSwitch");
		mReaderHelper.setOnRefreshOperateTagCallback("onRefreshOperateTag");
		mReaderHelper.setOnRefreshISO180006BCallback("onRefreshISO180006B");
		
		mReaderHelper.setOnRecvDataCallback("onRecvData");
		mReaderHelper.setOnSendDataCallback("onSendData");
		
		mReaderHelper.setOnLostConnectCallback("onLostConnect");
		m_curReaderSetting = mReaderHelper.getCurReaderSetting();	
		m_curInventoryBuffer = mReaderHelper.getCurInventoryBuffer();
		m_curOperateTagBuffer = mReaderHelper.getCurOperateTagBuffer();
		m_curOperateTagISO18000Buffer = mReaderHelper.getCurOperateTagISO18000Buffer();
		resetReader();
		enabledAll(true);
		break;
	}
}

function onRecvData(strData)
{
	if( DOC.getElementById("rd_openMonitor").checked ) {
		monitorAddItem(false, strData);
	}
}

function onSendData(strData)
{
	if( DOC.getElementById("rd_openMonitor").checked ) {
		monitorAddItem(true, strData);
	}
}

/* ����/��ȡ�ص����� */
function onLog(cmd, str, errCode)
{
	if (errCode == ERROR_SUCCESS) {		
		logAddItem(true, str);
		if( CMD_SET_WORK_ANTENNA == cmd ) {
			if ( mReaderHelper.getInventoryFlag() ) {
				runLoopInventroy();
			}
		}
	} else if (errCode == ERROR_FAIL) {
		
		if( CMD_SET_WORK_ANTENNA == cmd || 
			CMD_REAL_TIME_INVENTORY == cmd || 
			CMD_INVENTORY == cmd || 
			CMD_FAST_SWITCH_ANT_INVENTORY == cmd || 
			CMD_CUSTOMIZED_SESSION_TARGET_INVENTORY == cmd
		) {
			if( mReaderHelper.getInventoryFlag() ) {
				m_curInventoryBuffer.nCommond = 1;
				runLoopInventroy();
			}
		}
		
		logAddItem(false, str);
	}
	
	if( DOC.getElementById("rd_autoClearLog").checked ) {
		if( DOC.getElementById("log_tbl").rows.length > 100 ) {
			logRemoveAll();
		}
	}
	
	if (timer) clearTimeout(timer);
	enabledAll(true);
}

/* ��ȡ�ص�����(ˢ��ҳ������) */
function onRefreshSet(cmd)
{
	switch (cmd) {
	case CMD_GET_FIRMWARE_VERSION:
		DOC.getElementById("get_firmwareVersion").value = ((m_curReaderSetting.btMajor & 0xFF) + "." + (m_curReaderSetting.btMinor & 0xFF));
		break;
	case CMD_GET_WORK_ANTENNA:
		if (m_curReaderSetting.btWorkAntenna >= 0 && m_curReaderSetting.btWorkAntenna <= 3) {
			DOC.getElementById("antennasList").selectedIndex = (m_curReaderSetting.btWorkAntenna & 0xFF);
		}
		break;
	case CMD_GET_OUTPUT_POWER:
		if (m_curReaderSetting.btAryOutputPower != null && m_curReaderSetting.btAryOutputPower.length > 0) {
			DOC.getElementById("get_set_outputPower").value = (m_curReaderSetting.btAryOutputPower[0] & 0xFF);
		}
		break;
	case CMD_GET_FREQUENCY_REGION:
		var userDefine = window.document.getElementById("chk_userDefine");
		var startRegionList = window.document.getElementById("startRegionList");
		var endRegionList = window.document.getElementById("endRegionList");

		var region_FCC = window.document.getElementById("rd_region_FCC");
		var region_ETSI = window.document.getElementById("rd_region_ETSI");
		var region_CHN = window.document.getElementById("rd_region_CHN");

		var startFreq = window.document.getElementById("get_set_startFreq");
		var freqInterval = window.document.getElementById("get_set_freqInterval");
		var channelQuantity = window.document.getElementById("get_set_channelQuantity");
		
		if (m_curReaderSetting.blUserDefine) {
			userDefine.checked = true;
			initRegionList();
			startFreq.value = m_curReaderSetting.nUserDefineStartFrequency;
			freqInterval.value = m_curReaderSetting.btUserDefineFrequencyInterval * 10;
			channelQuantity.value = m_curReaderSetting.btUserDefineChannelQuantity;
		} else {
			userDefine.checked = false;
			
			region_FCC.checked = (m_curReaderSetting.btRegion == 0x01);
			region_ETSI.checked = (m_curReaderSetting.btRegion == 0x02);
			region_CHN.checked = (m_curReaderSetting.btRegion == 0x03);
			
			initRegionList();

			if (region_FCC.checked) {
				startRegionList.selectedIndex = (m_curReaderSetting.btFrequencyStart & 0xFF) - 7;
				endRegionList.selectedIndex = (m_curReaderSetting.btFrequencyEnd & 0xFF) - 7;
			} else if (region_ETSI.checked) {
				startRegionList.selectedIndex = (m_curReaderSetting.btFrequencyStart & 0xFF);
				endRegionList.selectedIndex = (m_curReaderSetting.btFrequencyEnd & 0xFF);
			} else if (region_CHN.checked) {
				startRegionList.selectedIndex = (m_curReaderSetting.btFrequencyStart & 0xFF) - 43;
				endRegionList.selectedIndex = (m_curReaderSetting.btFrequencyEnd & 0xFF) - 43;
			}
		}
		
		break;
	case CMD_GET_READER_TEMPERATURE:
		DOC.getElementById("get_temperature").value = (m_curReaderSetting.btTemperature & 0xFF);
		break;
	case CMD_READ_GPIO_VALUE:
		var gpio1_h = DOC.getElementById("get_Gpio1_H");
		var gpio1_l = DOC.getElementById("get_Gpio1_L");
		var gpio2_h = DOC.getElementById("get_Gpio2_H");
		var gpio2_l = DOC.getElementById("get_Gpio2_L");

		gpio1_h.checked = (m_curReaderSetting.btGpio1Value == 0x01);
		gpio1_l.checked = (m_curReaderSetting.btGpio1Value == 0x00);
		
		gpio2_h.checked = (m_curReaderSetting.btGpio2Value == 0x01);
		gpio2_l.checked = (m_curReaderSetting.btGpio2Value == 0x00);
		break;
	case CMD_GET_ANT_CONNECTION_DETECTOR:
		 DOC.getElementById("get_set_antConnectionDetector").value = (m_curReaderSetting.btAntDetector & 0xFF);
		break;
	case CMD_GET_READER_IDENTIFIER:
		if (m_curReaderSetting.btAryReaderIdentifier != null) {
			var str = byteArrayToString(m_curReaderSetting.btAryReaderIdentifier, 0, m_curReaderSetting.btAryReaderIdentifier.length);
			DOC.getElementById("get_readerIdentifier").value = str;
		}
		break;
	case CMD_GET_RF_LINK_PROFILE:
		var rfLinkProfile_0 = DOC.getElementById("rd_RfLinkProfile_0");
		var rfLinkProfile_1 = DOC.getElementById("rd_RfLinkProfile_1");
		var rfLinkProfile_2 = DOC.getElementById("rd_RfLinkProfile_2");
		var rfLinkProfile_3 = DOC.getElementById("rd_RfLinkProfile_3");
		
		rfLinkProfile_0.checked = ((m_curReaderSetting.btRfLinkProfile & 0xFF) == 0xD0);
		rfLinkProfile_1.checked = ((m_curReaderSetting.btRfLinkProfile & 0xFF) == 0xD1);
		rfLinkProfile_2.checked = ((m_curReaderSetting.btRfLinkProfile & 0xFF) == 0xD2);
		rfLinkProfile_3.checked = ((m_curReaderSetting.btRfLinkProfile & 0xFF) == 0xD3);
		break;
	case CMD_GET_RF_PORT_RETURN_LOSS:
		DOC.getElementById("get_ReturnLoss").value = (m_curReaderSetting.btReturnLoss & 0xFF);
		break;
	case CMD_GET_IMPINJ_FAST_TID:
		var impinjFastTid_ON = DOC.getElementById("get_set_impinjFastTid_ON");
		var impinjFastTid_OFF = DOC.getElementById("get_set_impinjFastTid_OFF");

		impinjFastTid_ON.checked = ((m_curReaderSetting.btMonzaStatus & 0xFF) == 0x8D);
		impinjFastTid_OFF.checked = ((m_curReaderSetting.btMonzaStatus & 0xFF) == 0x00);
		
		break;
	default:
		break;
	}
	
	if ((m_curReaderSetting.btReadId & 0xFF) != 0xFF) {
		DOC.getElementById("set_readerAddr").value = (m_curReaderSetting.btReadId & 0xFF).toString(16);
	}
}

function onRefreshInventory(cmd)
{
	switch(cmd) {
	case CMD_INVENTORY:
	{
		DOC.getElementById("text_inventoryBufferCount").innerHTML = m_curInventoryBuffer.nTagCount.toString(10);
		DOC.getElementById("text_inventoryBufferTotalCount").innerHTML = m_curInventoryBuffer.nTotalRead.toString(10);
		DOC.getElementById("text_inventoryBufferSpeed").innerHTML = m_curInventoryBuffer.nReadRate.toString(10);
		DOC.getElementById("text_inventoryBufferTotalTime").innerHTML = (m_curInventoryBuffer.dtEndInventory.getTime() - m_curInventoryBuffer.dtStartInventory.getTime()).toString(10);
		
		if (mReaderHelper.getInventoryFlag() && m_curInventoryBuffer.bLoopInventory ) {
			runLoopInventroy();
		}
		break;
	}
	case CMD_GET_INVENTORY_BUFFER:
	case CMD_GET_AND_RESET_INVENTORY_BUFFER:
	case CMD_RESET_INVENTORY_BUFFER:
	{
		DOC.getElementById("text_inventoryBufferCount").innerHTML = m_curInventoryBuffer.lsTagList.size().toString(10);
		DOC.getElementById("text_inventoryBufferTotalCount").innerHTML = m_curInventoryBuffer.nTotalRead.toString(10);
		//mMinRSSIText.setText(String.valueOf(m_curInventoryBuffer.nMinRSSI) + "dBm");
		//mMaxRSSIText.setText(String.valueOf(m_curInventoryBuffer.nMaxRSSI) + "dBm");
		
		inventoryBufferRemoveAll();
		
		for( var pos = 0 ; pos < m_curInventoryBuffer.lsTagList.size(); pos++ ) {
			var map = m_curInventoryBuffer.lsTagList.get(pos);
			inventoryBufferAddItem( 
				map.strPC, 
				map.strCRC, 
				map.strEPC, 
				map.btAntId.toString(10), 
				(parseInt(map.strRSSI) - 129).toString(10) + "dBm", 
				map.nReadCount.toString(10)
			);
		}
		
		break;
	}
	case INVENTORY_ERR:
	case INVENTORY_ERR_END:
	case INVENTORY_END:
		//if (mReaderHelper.getInventoryFlag()) {
			//stopInventoryReal();
		//}
		if (mReaderHelper.getInventoryFlag() && m_curInventoryBuffer.bLoopInventory ) {
			runLoopInventroy();
		}
		break;
	}
}

function onRefreshInventoryReal(cmd)
{
	switch(cmd) {
	case CMD_REAL_TIME_INVENTORY:
	case CMD_CUSTOMIZED_SESSION_TARGET_INVENTORY:
	{
		DOC.getElementById("text_inventoryRealCount").innerHTML = m_curInventoryBuffer.lsTagList.size().toString(10);
		DOC.getElementById("text_inventoryRealTotalCount").innerHTML = mReaderHelper.getInventoryTotal().toString(10);
		DOC.getElementById("text_inventoryRealSpeed").innerHTML = m_curInventoryBuffer.nReadRate.toString(10);
		DOC.getElementById("text_inventoryRealTotalTime").innerHTML = (m_curInventoryBuffer.dtEndInventory.getTime() - m_curInventoryBuffer.dtStartInventory.getTime()).toString(10);

		//mMinRSSIText.setText(String.valueOf(m_curInventoryBuffer.nMinRSSI) + "dBm");
		//mMaxRSSIText.setText(String.valueOf(m_curInventoryBuffer.nMaxRSSI) + "dBm");
		
		/*inventoryRealRemoveAll();
		
		for( var pos = 0 ; pos < m_curInventoryBuffer.lsTagList.size(); pos++ ) {
			var map = m_curInventoryBuffer.lsTagList.get(pos);
			inventoryRealAddItem( 
				map.strEPC, 
				map.strPC, 
				map.nReadCount.toString(10), 
				(parseInt(map.strRSSI) - 129).toString(10) + "dBm", 
				map.strFreq 
			);
		}*/
		
		break;
	}
	case INVENTORY_ERR:
	case INVENTORY_ERR_END:
	case INVENTORY_END:
		//if (mReaderHelper.getInventoryFlag()) {
			//stopInventoryReal();
		//}
		if (mReaderHelper.getInventoryFlag() && m_curInventoryBuffer.bLoopInventoryReal ) {
			runLoopInventroy();
		}
		break;
	}
}

function onRefreshFastSwitch(cmd)
{	
	switch(cmd) {
	case CMD_FAST_SWITCH_ANT_INVENTORY:
	{
		DOC.getElementById("text_fastSwitchCount").innerHTML = m_curInventoryBuffer.lsTagList.size().toString(10);
		DOC.getElementById("text_fastSwitchTotalCount").innerHTML = mReaderHelper.getInventoryTotal().toString(10);
		if (m_curInventoryBuffer.nCommandDuration > 0) {
			DOC.getElementById("text_fastSwitchSpeed").innerHTML = parseInt((m_curInventoryBuffer.nDataCount * 1000 / m_curInventoryBuffer.nCommandDuration)).toString(10);
        }
		DOC.getElementById("text_fastSwitchTotalTime").innerHTML = (m_curInventoryBuffer.dtEndInventory.getTime() - m_curInventoryBuffer.dtStartInventory.getTime()).toString(10);

		//mMinRSSIText.setText(String.valueOf(m_curInventoryBuffer.nMinRSSI) + "dBm");
		//mMaxRSSIText.setText(String.valueOf(m_curInventoryBuffer.nMaxRSSI) + "dBm");
		
		/*fastSwitchRemoveAll();
		
		for( var pos = 0 ; pos < m_curInventoryBuffer.lsTagList.size(); pos++ ) {
			var map = m_curInventoryBuffer.lsTagList.get(pos);
			fastSwitchAddItem( 
				map.strEPC, 
				map.strPC, 
				map.nAnt1.toString(10) + " / " + map.nAnt2.toString(10) + " / " + map.nAnt3.toString(10) + " / " + map.nAnt4.toString(10), 
				(parseInt(map.strRSSI) - 129).toString(10) + "dBm", 
				map.strFreq 
			);
		}*/
		break;
	}
	case INVENTORY_ERR:
	case INVENTORY_ERR_END:
	case INVENTORY_END:
		if (mReaderHelper.getInventoryFlag()) {
			if (m_curInventoryBuffer.bLoopInventory) {
				mReader.fastSwitchAntInventory(m_curReaderSetting.btReadId, 
				m_curInventoryBuffer.btA, m_curInventoryBuffer.btStayA, 
				m_curInventoryBuffer.btB, m_curInventoryBuffer.btStayB, 
				m_curInventoryBuffer.btC, m_curInventoryBuffer.btStayC, 
				m_curInventoryBuffer.btD, m_curInventoryBuffer.btStayD, 
				m_curInventoryBuffer.btInterval, m_curInventoryBuffer.btFastRepeat);
			}
		}
		break;
	}
}

function onRefreshOperateTag(cmd)
{

	switch(cmd) {
	case CMD_GET_ACCESS_EPC_MATCH:
		DOC.getElementById("text_operateTagSelectEpc").innerHTML = m_curOperateTagBuffer.strAccessEpcMatch;
		break;
	case CMD_READ_TAG:
	case CMD_WRITE_TAG:
	case CMD_LOCK_TAG:
	case CMD_KILL_TAG:
		
		operateTagRemoveAll();
		for( var pos = 0 ; pos < m_curOperateTagBuffer.lsTagList.size(); pos++ ) {
			var map = m_curOperateTagBuffer.lsTagList.get(pos);
			operateTagAddItem( 
				map.strPC, 
				map.strCRC, 
				map.strEPC, 
				map.strData, 
				map.nDataLen.toString(10), 
				map.btAntId.toString(10), 
				map.nDataLen.toString(10), 
				map.nReadCount.toString(10)
			);
		}
		break;
	}
}

function onRefreshISO180006B(cmd)
{
	switch(cmd) {
	case CMD_ISO18000_6B_INVENTORY:
	{
		//DOC.getElementById("text_inventoryRealCount").innerHTML = m_curInventoryBuffer.lsTagList.size().toString(10);
		//DOC.getElementById("text_inventoryRealTotalCount").innerHTML = mReaderHelper.getInventoryTotal().toString(10);
		//DOC.getElementById("text_inventoryRealSpeed").innerHTML = m_curInventoryBuffer.nReadRate.toString(10);
		//DOC.getElementById("text_inventoryRealTotalTime").innerHTML = (m_curInventoryBuffer.dtEndInventory.getTime() - m_curInventoryBuffer.dtStartInventory.getTime()).toString(10);

		//mMinRSSIText.setText(String.valueOf(m_curInventoryBuffer.nMinRSSI) + "dBm");
		//mMaxRSSIText.setText(String.valueOf(m_curInventoryBuffer.nMaxRSSI) + "dBm");
		
		/*var  operateTagUid6BList = DOC.getElementById("operateTag6BUIDList");
		operateTagUid6BList.options.length = 0;
		inventory6BRemoveAll();
		
		for( var pos = 0 ; pos < m_curOperateTagISO18000Buffer.lsTagList.size(); pos++ ) {
			var map = m_curOperateTagISO18000Buffer.lsTagList.get(pos);
			inventory6BAddItem( 
				map.strUID, 
				map.btAntId.toString(10), 
				map.nTotal.toString(10)
			);
			operateTagUid6BList.options.add( new Option(map.strUID, pos));
		}*/
		
		break;
	}
	case INVENTORY_ERR:
	case INVENTORY_ERR_END:
	case INVENTORY_END:
		if (mReaderHelper.getISO6BContinue()) {
			mReader.iso180006BInventory(m_curReaderSetting.btReadId);
		}
		break;
	case CMD_ISO18000_6B_READ_TAG:
		//mReadDataEditText.setText(m_curOperateTagISO18000Buffer.strReadData);
		DOC.getElementById("text_OperateTag6BReadData").value = m_curOperateTagISO18000Buffer.strReadData;
		break;
	case CMD_ISO18000_6B_QUERY_LOCK_TAG:
		switch (m_curOperateTagISO18000Buffer.btStatus & 0xFF) {
		case 0x00:
			//mWPStatusText.setText(getResources().getString(R.string.unlocked));
			DOC.getElementById("text_OperateTag6BWPStatus").value = "UNLOCK";
			break;
		case 0xFE:
			//mWPStatusText.setText(getResources().getString(R.string.locked));
			DOC.getElementById("text_OperateTag6BWPStatus").value = "LOCK";
			break;
		}
		break;
	}
}

/* ����/��ȡ�ص����� */
function onLostConnect()
{
	if (timer) clearTimeout(timer);
	alert("���Ӷ�ʧ,���������Ӷ�д��!");
	enabledAll(false);
	refreshConnectBtn();
}

function resetReader()
{
	if (mReader) {
		mReader.reset(0xFF);
	}
}

/* ���Ӻ��� */
function connect()
{
	var host = DOC.getElementById("tcpAddr").value;
	var port = parseInt(DOC.getElementById("tcpPort").value);
	if(isNaN(port)) {
		alert("�˿ںŲ���Ϊ��, �ұ���Ϊ����!");
	} else {
	
		setCookie('set_tcp_ip_host', host);
		setCookie('set_tcp_ip_port', port.toString());
		
		disabledById("btn_connect_tcp");
		disabledById("btn_disconnect_tcp");
		UHF.Connect(host, port);
	}
}

function connectCom()
{
	var port = DOC.getElementById("rs232Port").value;
	var baud = parseInt(DOC.getElementById("rs232Baud").value);
    
	if( port == null ) {
		alert("�˿ںŲ���Ϊ��!");
    } else if(isNaN(baud)) {
		alert("�����ʲ���Ϊ��, �ұ���Ϊ����!");
	} else {
		disabledById("btn_connect_rs232");
		disabledById("btn_disconnect_rs232");
		UHF.ConnectCom(port, baud);
	}
}

function disconnect()
{
	enabledAll(false);
	UHF.DisConnect();
	refreshConnectBtn();
}

/* ���ö�д����ַ */
function setReaderAddress()
{
	/* parseInt �ַ���ת���� */
	var addr = parseInt(DOC.getElementById("set_readerAddr").value, 16);
	if(isNaN(addr)) {
		alert("��ַ����Ϊ��, �ұ���Ϊ����!");
	} else {
		disabledById("btn_setReaderAddress");
		setTimeoutCall();
		mReader.setReaderAddress(m_curReaderSetting.btReadId, addr);
	}
}

/* ���ö�д��ʶ���ʶ */
function setReaderIdentifier()
{
	var str = DOC.getElementById("set_readerIdentifier").value;

	var dentifier = stringToByteArray(str);
	
	if(!dentifier || dentifier.length != 12) {
		alert("����16������ֵ�����ʶ,���Կո����");
	} else {
		setTimeoutCall();
		mReader.setReaderIdentifier(m_curReaderSetting.btReadId, dentifier);
	}
}

/* ��ȡ��д��ʶ���ʶ */
function getReaderIdentifier()
{
	//DOC.getElementById("get_readerIdentifier").value = "";
	setTimeoutCall();
	mReader.getReaderIdentifier(m_curReaderSetting.btReadId);
}

/* ��ȡ��д���̼��汾 */
function getFirmwareVersion()
{
	//DOC.getElementById("get_firmwareVersion").value = "";
	setTimeoutCall();
	mReader.getFirmwareVersion(m_curReaderSetting.btReadId);
}

/* ��ѯ��ǰ�豸�Ĺ����¶� */
function getReaderTemperature()
{
	//DOC.getElementById("get_temperature").value = "";
	setTimeoutCall();
	mReader.getReaderTemperature(m_curReaderSetting.btReadId);
}

/* ��ȡGPIO��ƽ�� */
function readGpioValue()
{
	setTimeoutCall();
	mReader.readGpioValue(m_curReaderSetting.btReadId);
}

/* ����GPIO3��ƽ�� */
function writeGpioValue3()
{
	var h = DOC.getElementById("set_Gpio3_H").checked;
	var l = DOC.getElementById("set_Gpio3_L").checked;
	
	if (!h && !l) {
		alert("������GPIO3��/�͵�ƽ!");
	}
	setTimeoutCall();
	mReader.writeGpioValue(m_curReaderSetting.btReadId, 0x03, (h ? 0x01 : 0x00));
}

/* ����GPIO4��ƽ�� */
function writeGpioValue4()
{
	var h = DOC.getElementById("set_Gpio4_H").checked;
	var l = DOC.getElementById("set_Gpio4_L").checked;
	
	if (!h && !l) {
		alert("������GPIO4��/�͵�ƽ!");
	}
	setTimeoutCall();
	mReader.writeGpioValue(m_curReaderSetting.btReadId, 0x03, (h ? 0x01 : 0x00));
}

/* ���÷�����״̬�� */
function setBeeperMode()
{
	var mode_1 = DOC.getElementById("set_beeperMode_1").checked;
	var mode_2 = DOC.getElementById("set_beeperMode_2").checked;
	var mode_3 = DOC.getElementById("set_beeperMode_3").checked;
	
	if (!mode_1 && !mode_2 && !mode_3) {
		alert("��ѡ��һ�ַ�����״̬!");
	} else {
		setTimeoutCall();
		mReader.setBeeperMode(m_curReaderSetting.btReadId, (mode_1 ? 0x00 : (mode_2 ? 0x01 : (mode_3 ? 0x02 : 0x00))));
	}
}

/* ���ö�д���������ߡ� */
function setWorkAntenna()
{
	var obj = DOC.getElementById("antennasList");
	var antenna = obj.options[obj.selectedIndex].value;
	setTimeoutCall();
	mReader.setWorkAntenna(m_curReaderSetting.btReadId, antenna & 0xFF);
}

/* ��ѯ��ǰ���߹������ߡ� */
function getWorkAntenna()
{
	setTimeoutCall();
	mReader.getWorkAntenna(m_curReaderSetting.btReadId);
}

/* ���ö�д����Ƶ�������(��ʽ1)�� */
function setOutputPower()
{
	var power = parseInt(DOC.getElementById("get_set_outputPower").value);
	if(isNaN(power)) {
		alert("������10���ƹ���ֵ!");
	} else {
		setTimeoutCall();
		mReader.setOutputPower(m_curReaderSetting.btReadId, power & 0xFF);
	}
}

/* ��ѯ��д����ǰ������ʡ� */
function getOutputPower()
{
	setTimeoutCall();
	mReader.getOutputPower(m_curReaderSetting.btReadId);
}

/* �������߶˿ڵĻز���ġ� */
function getRfPortReturnLoss()
{
	var returnLossList = DOC.getElementById("returnLossList");
	var frequency = returnLossList.options[returnLossList.selectedIndex].value;
	setTimeoutCall();
	mReader.getRfPortReturnLoss(m_curReaderSetting.btReadId, frequency & 0xFF);
}

/* �����������Ӽ����״̬�� */
function setAntConnectionDetector()
{
	var detector = parseInt(DOC.getElementById("get_set_antConnectionDetector").value);
	if(isNaN(detector)) {
		alert("������10���ƻز������ֵ!");
	} else {
		setTimeoutCall();
		mReader.setAntConnectionDetector(m_curReaderSetting.btReadId, detector & 0xFF);
	}
}

/* ��ȡ�������Ӽ����״̬�� */
function getAntConnectionDetector()
{
	setTimeoutCall();
	mReader.getAntConnectionDetector(m_curReaderSetting.btReadId);
}

/* ����Monza��ǩ���ٶ�TID(����Flash)�� */
function setImpinjFastTid()
{
	var impinjFastTid_ON = DOC.getElementById("get_set_impinjFastTid_ON");
	var impinjFastTid_OFF = DOC.getElementById("get_set_impinjFastTid_OFF");
	
	if (!impinjFastTid_ON.checked && !impinjFastTid_OFF.checked) {
		alert("��ѡ���/�ر�!");
	} else {
		setTimeoutCall();
		mReader.setImpinjFastTid(m_curReaderSetting.btReadId, impinjFastTid_ON.checked, false);
	}
}

/* ��ѯ��ǰ�Ŀ���TID���á� */
function getImpinjFastTid()
{
	setTimeoutCall();
	mReader.getImpinjFastTid(m_curReaderSetting.btReadId);
}

/* ���ö�д������Ƶ�ʷ�Χ(ʹ��ϵͳĬ�ϵ�Ƶ��/�û��Զ���Ƶ��)�� */
function setFrequencyRegion()
{
	var userDefine = DOC.getElementById("chk_userDefine");
	if (userDefine.checked) {
		var startFreq = parseInt(DOC.getElementById("get_set_startFreq").value);
		var freqInterval = parseInt(DOC.getElementById("get_set_freqInterval").value);
		var channelQuantity = parseInt(DOC.getElementById("get_set_channelQuantity").value);
		
		if(isNaN(startFreq) || isNaN(freqInterval) || isNaN(channelQuantity)) {
			alert("������10�����Զ���Ƶ��ֵ!");
		} else {
			setTimeoutCall();
			freqInterval = freqInterval / 10;
			mReader.setUserDefineFrequency(m_curReaderSetting.btReadId, freqInterval & 0xFF, channelQuantity & 0xFF, startFreq & 0xFFFFFFFF);
		}
	} else {
		var startRegionList = window.document.getElementById("startRegionList");
		var endRegionList = window.document.getElementById("endRegionList");

		var region_FCC = window.document.getElementById("rd_region_FCC");
		var region_ETSI = window.document.getElementById("rd_region_ETSI");
		var region_CHN = window.document.getElementById("rd_region_CHN");
		
		if (!region_FCC.checked && !region_ETSI.checked && !region_CHN.checked) {
			alert("��ѡ��һ��ϵͳƵ��ģʽ!");
		} else if (startRegionList.selectedIndex > endRegionList.selectedIndex) {
			alert("Ƶ�׷�Χ�����Ϲ淶����ο�ͨѶЭ��!");
		} else {
		
			var btRegion = 0x00;
			var btStartFreq = 0x00;
			var btEndFreq = 0x00;
			
			if (region_FCC.checked) {
				btRegion = 0x01;
				btStartFreq = (startRegionList.selectedIndex + 7) & 0xFF;
				btEndFreq = (endRegionList.selectedIndex + 7) & 0xFF;
			} else if (region_ETSI.checked) {
				btRegion = 0x02;
				btStartFreq = startRegionList.selectedIndex & 0xFF;
				btEndFreq = endRegionList.selectedIndex & 0xFF;
			} else if (region_CHN.checked) {
				btRegion = 0x03;
				btStartFreq = (startRegionList.selectedIndex + 43) & 0xFF;
				btEndFreq = (endRegionList.selectedIndex + 43) & 0xFF;
			}
		
			setTimeoutCall();
			mReader.setFrequencyRegion(m_curReaderSetting.btReadId, btRegion, btStartFreq, btEndFreq);
		}
	}
}

/* ��ѯ��д������Ƶ�ʷ�Χ�� */
function getFrequencyRegion()
{
	setTimeoutCall();
	mReader.getFrequencyRegion(m_curReaderSetting.btReadId);
}

/* ������Ƶ��·��ͨѶ���ʡ� */
function setRfLinkProfile()
{
	var rfLinkProfile_0 = DOC.getElementById("rd_RfLinkProfile_0");
	var rfLinkProfile_1 = DOC.getElementById("rd_RfLinkProfile_1");
	var rfLinkProfile_2 = DOC.getElementById("rd_RfLinkProfile_2");
	var rfLinkProfile_3 = DOC.getElementById("rd_RfLinkProfile_3");
	
	if (!rfLinkProfile_0.checked && !rfLinkProfile_1.checked && !rfLinkProfile_2.checked && !rfLinkProfile_3.checked) {
		alert("��ѡ��һ��ͨ������!");
	} else {
	
		var selectedProfile = 0xFF;

		if (rfLinkProfile_0.checked) {
			selectedProfile = 0xD0;
		} else if (rfLinkProfile_1.checked) {
			selectedProfile = 0xD1;
		} else if (rfLinkProfile_2.checked) {
			selectedProfile = 0xD2;
		} else if (rfLinkProfile_3.checked) {
			selectedProfile = 0xD3;
		}
		
		setTimeoutCall();
		mReader.setRfLinkProfile(m_curReaderSetting.btReadId, selectedProfile & 0xFF);
	}
}

/* ��ȡ��Ƶ��·��ͨѶ���ʡ� */
function getRfLinkProfile()
{
	setTimeoutCall();
	mReader.getRfLinkProfile(m_curReaderSetting.btReadId);
}

function startInventoryReal()
{
	var inventoryRealNums = parseInt(DOC.getElementById("inventoryRealNums").value);
	var userDefineSession = DOC.getElementById("chk_userDefineSession");
	var sessionIdList = DOC.getElementById("sessionIdList");
	var inventoriedFlagList = DOC.getElementById("inventoriedFlagList");
	var inventoryRealAnt_1 = DOC.getElementById("rd_inventoryRealAnt_1");
	var inventoryRealAnt_2 = DOC.getElementById("rd_inventoryRealAnt_2");
	var inventoryRealAnt_3 = DOC.getElementById("rd_inventoryRealAnt_3");
	var inventoryRealAnt_4 = DOC.getElementById("rd_inventoryRealAnt_4");

	m_curInventoryBuffer.clearInventoryPar();
	if (isNaN(inventoryRealNums)) {
		alert("������ѭ������");
		return ;
	} else {
		m_curInventoryBuffer.btRepeat = inventoryRealNums;
		if (userDefineSession.checked) {
			m_curInventoryBuffer.bLoopCustomizedSession = true;
			m_curInventoryBuffer.btSession = sessionIdList.selectedIndex;
			m_curInventoryBuffer.btTarget = inventoriedFlagList.selectedIndex;
		} else {
			m_curInventoryBuffer.bLoopCustomizedSession = false;
		}
		
		if (inventoryRealAnt_1.checked) {
			m_curInventoryBuffer.lAntenna.add(0x00);
		}
		
		if (inventoryRealAnt_2.checked) {
			m_curInventoryBuffer.lAntenna.add(0x01);
		}
		
		if (inventoryRealAnt_3.checked) {
			m_curInventoryBuffer.lAntenna.add(0x02);
		}
		
		if (inventoryRealAnt_4.checked) {
			m_curInventoryBuffer.lAntenna.add(0x03);
		}
		
		if (m_curInventoryBuffer.lAntenna.size() <= 0) {
			alert("������ѡ��һ������");
			return;
		}
		
		m_curInventoryBuffer.bLoopInventory = true;
		m_curInventoryBuffer.bLoopInventoryReal = true;
		
		m_curInventoryBuffer.clearInventoryRealResult();
		mReaderHelper.setInventoryFlag(true);
		
		mReaderHelper.clearInventoryTotal();
		
		var btWorkAntenna = m_curInventoryBuffer.lAntenna.get(m_curInventoryBuffer.nIndexAntenna);
		if (btWorkAntenna < 0) btWorkAntenna = 0;
		mReader.SetWorkAntenna(m_curReaderSetting.btReadId, btWorkAntenna);
		
		if (timerInventoryReal) clearTimeout(timerInventoryReal);
		timerInventoryReal = setTimeout('onTimerInventoryReal()', 2000);
	}
}

function stopInventoryReal()
{
	mReaderHelper.setInventoryFlag(false);
	m_curInventoryBuffer.bLoopInventoryReal = false;
	
	if (timerInventoryReal) clearTimeout(timerInventoryReal);
	onTimerInventoryReal();
}

function startInventoryBuffer()
{
	var inventoryBufferNums = parseInt(DOC.getElementById("inventoryBufferNums").value);
	var inventoryBufferAnt_1 = DOC.getElementById("rd_inventoryBufferAnt_1");
	var inventoryBufferAnt_2 = DOC.getElementById("rd_inventoryBufferAnt_2");
	var inventoryBufferAnt_3 = DOC.getElementById("rd_inventoryBufferAnt_3");
	var inventoryBufferAnt_4 = DOC.getElementById("rd_inventoryBufferAnt_4");

	m_curInventoryBuffer.clearInventoryPar();
	if (isNaN(inventoryBufferNums)) {
		alert("������ѭ������");
		return ;
	} else {
		m_curInventoryBuffer.btRepeat = inventoryBufferNums;
		if (inventoryBufferAnt_1.checked) {
			m_curInventoryBuffer.lAntenna.add(0x00);
		}
		
		if (inventoryBufferAnt_2.checked) {
			m_curInventoryBuffer.lAntenna.add(0x01);
		}
		
		if (inventoryBufferAnt_3.checked) {
			m_curInventoryBuffer.lAntenna.add(0x02);
		}
		
		if (inventoryBufferAnt_4.checked) {
			m_curInventoryBuffer.lAntenna.add(0x03);
		}
		
		if (m_curInventoryBuffer.lAntenna.size() <= 0) {
			alert("������ѡ��һ������");
			return;
		}
		
		m_curInventoryBuffer.bLoopInventory = true;
		
		m_curInventoryBuffer.clearInventoryRealResult();
		mReaderHelper.setInventoryFlag(true);
		
		mReaderHelper.clearInventoryTotal();
		
		var btWorkAntenna = m_curInventoryBuffer.lAntenna.get(m_curInventoryBuffer.nIndexAntenna);
		if (btWorkAntenna < 0) btWorkAntenna = 0;
		mReader.SetWorkAntenna(m_curReaderSetting.btReadId, btWorkAntenna);
	}
}

function stopInventoryBuffer()
{
	mReaderHelper.setInventoryFlag(false);
	m_curInventoryBuffer.bLoopInventory = false;
}

function getInventoryBuffer()
{
	m_curInventoryBuffer.clearTagMap();
	inventoryBufferRemoveAll();
	mReader.getInventoryBuffer(m_curReaderSetting.btReadId);
}

function getAndResetInventoryBuffer()
{
	m_curInventoryBuffer.clearTagMap();
	inventoryBufferRemoveAll();
	mReader.getAndResetInventoryBuffer(m_curReaderSetting.btReadId);
}

function resetInventoryBuffer()
{
	m_curInventoryBuffer.clearInventoryRealResult();
	inventoryBufferRemoveAll();
	DOC.getElementById("text_inventoryBufferCount").innerHTML = "0";
	DOC.getElementById("text_inventoryBufferTotalCount").innerHTML = "0";
	DOC.getElementById("text_inventoryBufferSpeed").innerHTML = "0";
	DOC.getElementById("text_inventoryBufferTotalTime").innerHTML = "0";
	mReader.resetInventoryBuffer(m_curReaderSetting.btReadId);
}

function getInventoryBufferTagCount()
{
	mReader.getInventoryBufferTagCount(m_curReaderSetting.btReadId);
}

function startFastSwitch()
{
	var mPosA = DOC.getElementById("fastSwitchAList").selectedIndex;
	var mPosB = DOC.getElementById("fastSwitchBList").selectedIndex;
	var mPosC = DOC.getElementById("fastSwitchCList").selectedIndex;
	var mPosD = DOC.getElementById("fastSwitchDList").selectedIndex;
	var btStayA = parseInt(DOC.getElementById("fastSwitchARetrys").value);
	var btStayB = parseInt(DOC.getElementById("fastSwitchBRetrys").value);
	var btStayC = parseInt(DOC.getElementById("fastSwitchCRetrys").value);
	var btStayD = parseInt(DOC.getElementById("fastSwitchDRetrys").value);
	var btInterval = parseInt(DOC.getElementById("fastSwitchAntDelay").value);
	var btRepeat = parseInt(DOC.getElementById("fastSwitchRetrys").value);

	m_curInventoryBuffer.clearInventoryRealResult();
	mReaderHelper.setInventoryTotal(0);
	fastSwitchRemoveAll();
	if (isNaN(btStayA) || isNaN(btStayB) || isNaN(btStayC) || isNaN(btStayD)) {
		alert("��������ѵ����");
		return ;
	} else if (isNaN(btInterval)) {
		alert("���������߼���ʱ");
		return ;
	} else if(isNaN(btRepeat) || btRepeat <= 0) {
		alert("������ѭ������");
		return ;
	} else {
	
		if ((mPosA == 4 && mPosB == 4 && mPosC == 4 && mPosD == 4) ||
				(mPosA != 4 && btStayA < 0) ||
				(mPosB != 4 && btStayB < 0) ||
				(mPosC != 4 && btStayC < 0) ||
				(mPosD != 4 && btStayD < 0)) {
			alert("����ѡ��һ����Ч����");
			return ;
		}

		mReaderHelper.setInventoryFlag(true);
		m_curInventoryBuffer.bLoopInventory = true;
		
		mReader.fastSwitchAntInventory(
			m_curReaderSetting.btReadId, 
			mPosA, btStayA, mPosB, btStayB, 
			mPosC, btStayC, mPosD, btStayD, 
			btInterval, btRepeat
		);
		
		if (timerFastSwitch) clearTimeout(timerFastSwitch);
		timerFastSwitch = setTimeout('onTimerFastSwitch()', 2000);
		
		m_curInventoryBuffer.btA = mPosA;
		m_curInventoryBuffer.btB = mPosB;
		m_curInventoryBuffer.btC = mPosC;
		m_curInventoryBuffer.btD = mPosD;
		
		m_curInventoryBuffer.btStayA = btStayA;
		m_curInventoryBuffer.btStayB = btStayB;
		m_curInventoryBuffer.btStayC = btStayC;
		m_curInventoryBuffer.btStayD = btStayD;
		
		m_curInventoryBuffer.btInterval = btInterval;
		m_curInventoryBuffer.btFastRepeat = btRepeat;
	}
}

function stopFastSwitch()
{
	mReaderHelper.setInventoryFlag(false);
	m_curInventoryBuffer.bLoopInventory = false;
	
	if (timerFastSwitch) clearTimeout(timerFastSwitch);
	onTimerFastSwitch();
}

function operateTagEpcListInit()
{
	if( m_curInventoryBuffer ) {
		var  operateTagEpcList = DOC.getElementById("operateTagEpcList");
		operateTagEpcList.options.length = 0;
		for(var i = 0; i < m_curInventoryBuffer.lsTagList.size(); i++) {
			operateTagEpcList.options.add(
				new Option(
					m_curInventoryBuffer.lsTagList.get(i).strEPC, 
					i
				)
			);
		}
	}
}

function selectOperateTag()
{
	var operateTagEpcList = DOC.getElementById("operateTagEpcList");
	var epc = "";
	
	if( operateTagEpcList.options.length > 0 ) {
		epc = operateTagEpcList.options[operateTagEpcList.selectedIndex].text;
	}
	
	if( epc.length <= 1 ) {
		alert("δѡ���κα�ǩ");
		
		return ;
	}
	
	var btAryEpc = stringToByteArray(epc);
	if (!btAryEpc) {
		alert("��ǩ��ʽ����");
		return;
	}
	mReader.setAccessEpcMatch(m_curReaderSetting.btReadId, btAryEpc.length & 0xFF, btAryEpc);
	//DOC.getElementById("text_operateTagSelectEpc").innerHTML = epc;
}

function unselectOperateTag()
{
	mReader.cancelAccessEpcMatch(m_curReaderSetting.btReadId);
	DOC.getElementById("text_operateTagSelectEpc").innerHTML = "";
}

function readTag()
{
	var btMemBank;
	var btWordAdd;
	var btWordCnt;
	var btAryPassWord;
	
	var rdPsk = DOC.getElementById("rd_OperateTagReadWriteArea_Psk");
	var rdEpc = DOC.getElementById("rd_OperateTagReadWriteArea_Epc");
	var rdTid = DOC.getElementById("rd_OperateTagReadWriteArea_Tid");
	var rdUser = DOC.getElementById("rd_OperateTagReadWriteArea_User");
	
	if (rdPsk.checked) {
		btMemBank = 0x00;
	} else if (rdEpc.checked) {
		btMemBank = 0x01;
	} else if (rdTid.checked) {
		btMemBank = 0x02;
	} else if (rdUser.checked) {
		btMemBank = 0x03;
	}
	
	btAryPassWord = stringToByteArray(DOC.getElementById("text_OperateTagReadWritePsk").value);
	
	btWordAdd = parseInt(DOC.getElementById("text_OperateTagReadWriteAddr").value);
	btWordCnt = parseInt(DOC.getElementById("text_OperateTagReadWriteLen").value);
	
	if( !btAryPassWord || btAryPassWord.length != 4 ) {
		alert("�����ʽ����");
		return ;
	} else if( isNaN(btWordAdd) ) {
		alert("��ַ��ʽ����");
		return ;
	} else if( isNaN(btWordCnt) ) {
		alert("��Ŀ��ʽ����");
		return ;
	}

	m_curOperateTagBuffer.clearBuffer();
	operateTagRemoveAll();

	mReader.readTag(m_curReaderSetting.btReadId, btMemBank, btWordAdd, btWordCnt, btAryPassWord);
}

function writeTag()
{
	var btMemBank;
	var btWordAdd;
	var btWordCnt;
	var btAryPassWord;
	
	var rdPsk = DOC.getElementById("rd_OperateTagReadWriteArea_Psk");
	var rdEpc = DOC.getElementById("rd_OperateTagReadWriteArea_Epc");
	var rdTid = DOC.getElementById("rd_OperateTagReadWriteArea_Tid");
	var rdUser = DOC.getElementById("rd_OperateTagReadWriteArea_User");
	var btAryData;
	
	if (rdPsk.checked) {
		btMemBank = 0x00;
	} else if (rdEpc.checked) {
		btMemBank = 0x01;
	} else if (rdTid.checked) {
		btMemBank = 0x02;
	} else if (rdUser.checked) {
		btMemBank = 0x03;
	}
	
	btAryData = stringToByteArray(DOC.getElementById("text_OperateTagWriteData").value);
	btAryPassWord = stringToByteArray(DOC.getElementById("text_OperateTagReadWritePsk").value);
	
	btWordAdd = parseInt(DOC.getElementById("text_OperateTagReadWriteAddr").value);
	
	if( !btAryPassWord || btAryPassWord.length != 4 ) {
		alert("�����ʽ����");
		return ;
	} else if( !btAryData || btAryData.length <= 0 ) {
		alert("д�����ݸ�ʽ����");
		return ;
	} else if( isNaN(btWordAdd) ) {
		alert("��ַ��ʽ����");
		return ;
	}
	
	btWordCnt = ((btAryData.length / 2) + (btAryData.length % 2)) & 0xFF;

	m_curOperateTagBuffer.clearBuffer();
	operateTagRemoveAll();
	mReader.writeTag(m_curReaderSetting.btReadId, btAryPassWord, btMemBank, btWordAdd, btWordCnt, btAryData);
}

function lockTag()
{
	var btMemBank;
	var btLockType;
	var btAryPassWord;
	
	var rdReadPsk = DOC.getElementById("rd_OperateTagLockArea_ReadPsk");
	var rdKillPsk = DOC.getElementById("rd_OperateTagLockArea_KillPsk");
	var rdEpc = DOC.getElementById("rd_OperateTagLockArea_Epc");
	var rdTid = DOC.getElementById("rd_OperateTagLockArea_Tid");
	var rdUser = DOC.getElementById("rd_OperateTagLockArea_User");
	
	if (rdReadPsk.checked) {
		btMemBank = 0x04;
	} else if (rdKillPsk.checked) {
		btMemBank = 0x05;
	} else if (rdEpc.checked) {
		btMemBank = 0x03;
	} else if (rdTid.checked) {
		btMemBank = 0x02;
	} else if (rdUser.checked) {
		btMemBank = 0x01;
	}
	
	var rdOpen = DOC.getElementById("rd_OperateTagLockType_Open");
	var rdLock = DOC.getElementById("rd_OperateTagLockType_Lock");
	var rdOpenEver = DOC.getElementById("rd_OperateTagLockType_OpenEver");
	var rdLockEver = DOC.getElementById("rd_OperateTagLockType_LockEver");
	if (rdOpen.checked) {
		btLockType = 0x00;
	} else if (rdLock.checked) {
		btLockType = 0x01;
	} else if (rdOpenEver.checked) {
		btLockType = 0x02;
	} else if (rdLockEver.checked) {
		btLockType = 0x03;
	}
	
	btAryPassWord = stringToByteArray(DOC.getElementById("text_OperateTagLockPsk").value);
	
	if( !btAryPassWord || btAryPassWord.length != 4 ) {
		alert("�����ʽ����");
		return ;
	}
	
	m_curOperateTagBuffer.clearBuffer();
	operateTagRemoveAll();
	mReader.lockTag(m_curReaderSetting.btReadId, btAryPassWord, btMemBank, btLockType);
}

function killTag()
{
	var btAryPassWord = stringToByteArray(DOC.getElementById("text_OperateTagKillPsk").value);
	
	if( !btAryPassWord || btAryPassWord.length < 4 ) {
		alert("�����ʽ����");
		return ;
	}
	
	m_curOperateTagBuffer.clearBuffer();
	operateTagRemoveAll();
	mReader.killTag(m_curReaderSetting.btReadId, btAryPassWord);
}

function startInventory6B()
{
	mReaderHelper.setISO6BContinue(true);
	m_curOperateTagISO18000Buffer.clearBuffer();
	mReader.iso180006BInventory(m_curReaderSetting.btReadId);
	
	if (timerInventoryReal6B) clearTimeout(timerInventoryReal6B);
	timerInventoryReal6B = setTimeout('onTimerInventoryReal6B()', 2000);
}

function stopInventory6B()
{
	mReaderHelper.setISO6BContinue(false);
	if (timerInventoryReal6B) clearTimeout(timerInventoryReal6B);
	onTimerInventoryReal6B();
}

function readTag6B()
{
	var btWordAdd = parseInt(DOC.getElementById("text_OperateTag6BReadAddr").value, 16);
	var btWordCnt = parseInt(DOC.getElementById("text_OperateTag6BReadLen").value, 16);
	
	if( isNaN(btWordAdd) ) {
		alert("��ַ��ʽ����");
		return ;
	} else if( isNaN(btWordCnt) ) {
		alert("���ݳ��ȸ�ʽ����");
		return ;
	}
	
	var operateTagUid6BList = DOC.getElementById("operateTag6BUIDList");
	var uid = "";
	
	if( operateTagUid6BList.options.length > 0 ) {
		uid = operateTagUid6BList.options[operateTagUid6BList.selectedIndex].text;
	}
	
	if( uid.length <= 1 ) {
		alert("δѡ���κ�6B��ǩ");
		return ;
	}
	
	var btAryUID = stringToByteArray(uid);
	if (!btAryUID) {
		alert("6B��ǩ��ʽ����");
		return;
	}
	
	mReader.iso180006BReadTag(m_curReaderSetting.btReadId, btAryUID, btWordAdd, btWordCnt);
}

function writeTag6B()
{
	var btWordAdd = parseInt(DOC.getElementById("text_OperateTag6BWriteAddr").value, 16);
	var btWordCnt;
	
	if( isNaN(btWordAdd) ) {
		alert("��ַ��ʽ����");
		return ;
	}
	
	var operateTagUid6BList = DOC.getElementById("operateTag6BUIDList");
	var uid = "";
	
	if( operateTagUid6BList.options.length > 0 ) {
		uid = operateTagUid6BList.options[operateTagUid6BList.selectedIndex].text;
	}
	
	if( uid.length <= 1 ) {
		alert("δѡ���κ�6B��ǩ");
		return ;
	}
	
	var btAryUID = stringToByteArray(uid);
	if (!btAryUID) {
		alert("6B��ǩ��ʽ����");
		return;
	}
	
	var btAryBuffer = stringToByteArray(DOC.getElementById("text_OperateTag6BWriteData").value);
	
	if( !btAryBuffer || btAryBuffer.length <= 0 ) {
		alert("���ݸ�ʽ����");
		return ;
	}
	
	btWordCnt = btAryBuffer.length;
	
	DOC.getElementById("text_OperateTag6BWriteLen").value = btWordCnt.toString(16);
	
	mReader.iso180006BWriteTag(m_curReaderSetting.btReadId, btAryUID, btWordAdd, btWordCnt, btAryBuffer);
}

function writeTag6BWPStatus()
{
	var btWordAdd = parseInt(DOC.getElementById("text_OperateTag6BWPSetAddr").value, 16);
	
	if( isNaN(btWordAdd) ) {
		alert("��ַ��ʽ����");
		return ;
	}
	
	var operateTagUid6BList = DOC.getElementById("operateTag6BUIDList");
	var uid = "";
	
	if( operateTagUid6BList.options.length > 0 ) {
		uid = operateTagUid6BList.options[operateTagUid6BList.selectedIndex].text;
	}
	
	if( uid.length <= 1 ) {
		alert("δѡ���κ�6B��ǩ");
		return ;
	}
	
	var btAryUID = stringToByteArray(uid);
	if (!btAryUID) {
		alert("6B��ǩ��ʽ����");
		return;
	}
	
	mReader.iso180006BLockTag(m_curReaderSetting.btReadId, btAryUID, btWordAdd);
}

function readTag6BWPStatus()
{
	var btWordAdd = parseInt(DOC.getElementById("text_OperateTag6BWPQueryAddr").value, 16);
	
	if( isNaN(btWordAdd) ) {
		alert("��ַ��ʽ����");
		return ;
	}
	
	var operateTagUid6BList = DOC.getElementById("operateTag6BUIDList");
	var uid = "";
	
	if( operateTagUid6BList.options.length > 0 ) {
		uid = operateTagUid6BList.options[operateTagUid6BList.selectedIndex].text;
	}
	
	if( uid.length <= 1 ) {
		alert("δѡ���κ�6B��ǩ");
		return ;
	}
	
	var btAryUID = stringToByteArray(uid);
	if (!btAryUID) {
		alert("6B��ǩ��ʽ����");
		return;
	}
	
	mReader.iso180006BQueryLockTag(m_curReaderSetting.btReadId, btAryUID, btWordAdd);
}

function runLoopInventroy()
{
	//У���̴��Ƿ��������߾����
	if ( m_curInventoryBuffer.nIndexAntenna < m_curInventoryBuffer.lAntenna.size() - 1 || m_curInventoryBuffer.nCommond == 0) {
		if (m_curInventoryBuffer.nCommond == 0) {
			m_curInventoryBuffer.nCommond = 1;
			
			if (m_curInventoryBuffer.bLoopInventoryReal) {
				//m_bLockTab = true;
				//btnInventory.Enabled = false;
				if (m_curInventoryBuffer.bLoopCustomizedSession) {		//�Զ���Session��Inventoried Flag 
					mReader.customizedSessionTargetInventory(m_curReaderSetting.btReadId, m_curInventoryBuffer.btSession, m_curInventoryBuffer.btTarget, m_curInventoryBuffer.btRepeat); 
				} else {	//ʵʱ�̴�
					mReader.realTimeInventory(m_curReaderSetting.btReadId, m_curInventoryBuffer.btRepeat);
					
				}
			} else if (m_curInventoryBuffer.bLoopInventory) {
				mReader.inventory(m_curReaderSetting.btReadId, m_curInventoryBuffer.btRepeat);
			}
		} else {
			m_curInventoryBuffer.nCommond = 0;
			m_curInventoryBuffer.nIndexAntenna++;

			var btWorkAntenna = m_curInventoryBuffer.lAntenna.get(m_curInventoryBuffer.nIndexAntenna);
			mReader.setWorkAntenna(m_curReaderSetting.btReadId, btWorkAntenna);
			m_curReaderSetting.btWorkAntenna = btWorkAntenna;
		}
	} else if (m_curInventoryBuffer.bLoopInventory || m_curInventoryBuffer.bLoopInventoryReal) {		//У���Ƿ�ѭ���̴�
		m_curInventoryBuffer.nIndexAntenna = 0;
		m_curInventoryBuffer.nCommond = 0;

		var btWorkAntenna = m_curInventoryBuffer.lAntenna.get(m_curInventoryBuffer.nIndexAntenna);
		mReader.setWorkAntenna(m_curReaderSetting.btReadId, btWorkAntenna);
		m_curReaderSetting.btWorkAntenna = btWorkAntenna;
	}
}

function checkSum(btAryBuffer, nStartPos, nLen)
{
	var btSum = 0x00;
	for (var nloop = nStartPos; nloop < nStartPos + nLen; nloop++ ) {
		btSum += btAryBuffer[nloop];
	}
	return (((~btSum) + 1) & 0xFF);
}

function monitorClear()
{
	DOC.getElementById("text_MonitorWriteData").value = "";
	DOC.getElementById("text_MonitorWriteDataCheck").value = "";
}

function monitorWrite()
{
	var szWriteData = DOC.getElementById("text_MonitorWriteData").value;
	var btAryWriteData = stringToByteArray(szWriteData);
	
	if( btAryWriteData.length > 1 ) {
		var btCheckSum = checkSum( btAryWriteData, 0, btAryWriteData.length );
		var szCheckSum = '0' + btCheckSum.toString(16).toUpperCase();
		szCheckSum = szCheckSum.substring( szCheckSum.length - 2 );
		DOC.getElementById("text_MonitorWriteDataCheck").value = "0x" + szCheckSum;
		//DOC.getElementById("text_MonitorWriteDataCheck").value = "0x" + btCheckSum.toString(16);
		btAryWriteData.push( btCheckSum );
		mReader.sendBuffer( btAryWriteData );
	}
}



