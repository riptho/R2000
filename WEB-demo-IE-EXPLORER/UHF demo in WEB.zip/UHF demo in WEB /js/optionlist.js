/* ����1-4 */
function initAntennasList()
{
	var obj = window.document.getElementById("antennasList");
	var startAntennasNum = 1;
	var startAntennasValue = 0;
	if (obj) {
		obj.options.length = 0;
		for (var num = startAntennasNum; 
			num < startAntennasNum + 4; 
			num+=1, startAntennasValue+=1) 
		{
			obj.options.add(new Option(" ����  " + num + " ", startAntennasValue));
		}
	}
}

function initReturnLossList()
{
	var returnLossList = window.document.getElementById("returnLossList");
	var startReturnLossNum = 865.00;
	var startReturnLossValue = 0;
	if (returnLossList) {
		returnLossList.options.length = 0;
		for (var num = startReturnLossNum; 
			num <= 868.00; 
			num += 0.5, startReturnLossValue+=1) 
		{
			var tmp = num.toString();
			if (tmp.length == 3) tmp += ".00";
			else if (tmp.length == 4) tmp += "00";
			else if (tmp.length == 5) tmp += "0";
			returnLossList.options.add(new Option(tmp, startReturnLossValue));
		}
		
		startReturnLossNum = 902.00;
		for (var num = startReturnLossNum; 
			num <= 928.00; 
			num += 0.5, startReturnLossValue+=1) 
		{
			var tmp = num.toString();
			if (tmp.length == 3) tmp += ".00";
			else if (tmp.length == 4) tmp += "00";
			else if (tmp.length == 5) tmp += "0";
			
			returnLossList.options.add(new Option(" " + tmp + " ", startReturnLossValue));
			
			if (num == 915.00) {
				returnLossList.selectedIndex = startReturnLossValue;
			}
		}
	}
}


/* ���������б� */
function initRegionList()
{
	var userDefine = window.document.getElementById("chk_userDefine");
	var startRegionList = window.document.getElementById("startRegionList");
	var endRegionList = window.document.getElementById("endRegionList");

	var region_FCC = window.document.getElementById("rd_region_FCC");
	var region_ETSI = window.document.getElementById("rd_region_ETSI");
	var region_CHN = window.document.getElementById("rd_region_CHN");
	
	var startFreq = window.document.getElementById("get_set_startFreq");
	var freqInterval = window.document.getElementById("get_set_freqInterval");
	var channelQuantity = window.document.getElementById("get_set_channelQuantity");

	if (userDefine.checked) {
		startRegionList.disabled = true;
		endRegionList.disabled = true;
		region_FCC.disabled = true;
		region_ETSI.disabled = true;
		region_CHN.disabled = true;
		
		startFreq.disabled = false;
		freqInterval.disabled = false;
		channelQuantity.disabled = false;
	} else {
	
		startRegionList.disabled = false;
		endRegionList.disabled = false;
		region_FCC.disabled = false;
		region_ETSI.disabled = false;
		region_CHN.disabled = false;
		
		startFreq.disabled = true;
		freqInterval.disabled = true;
		channelQuantity.disabled = true;
	
		var regionMin;
		var regionMax;
		var startRegionValue = 0;
		
		if (region_FCC.checked || region_ETSI.checked || region_CHN.checked) {
			regionMin = (region_FCC.checked ? 902.00 : (region_ETSI.checked ? 865.00 : (region_CHN.checked ? 920.00 : 0)));
			regionMax = (region_FCC.checked ? 928.00 : (region_ETSI.checked ? 868.00 : (region_CHN.checked ? 925.00 : 0)));
			
			startRegionList.options.length = 0;
			endRegionList.options.length = 0;
			
			for (var num = regionMin; 
				num <= regionMax; 
				num += 0.5, startRegionValue+=1) 
			{
				var tmp = num.toString();
				if (tmp.length == 3) tmp += ".00";
				else if (tmp.length == 4) tmp += "00";
				else if (tmp.length == 5) tmp += "0";
				startRegionList.options.add(new Option(tmp, startRegionValue));
				endRegionList.options.add(new Option(tmp, startRegionValue));
			}
		}
	}
}


function initUserDefineSessionList()
{
	var userDefineSession = window.document.getElementById("chk_userDefineSession");
	var sessionIdList = window.document.getElementById("sessionIdList");
	var inventoriedFlagList = window.document.getElementById("inventoriedFlagList");
	
	sessionIdList.options.add(new Option("S0"));
	sessionIdList.options.add(new Option("S1"));
	sessionIdList.options.add(new Option("S2"));
	sessionIdList.options.add(new Option("S3"));
	
	inventoriedFlagList.options.add(new Option("A"));
	inventoriedFlagList.options.add(new Option("B"));
	
	sessionIdList.disabled = !userDefineSession.checked;
	inventoriedFlagList.disabled = !userDefineSession.checked;
}

function initFastSwitchABCDList()
{
	var fastSwitchAList = window.document.getElementById("fastSwitchAList");
	var fastSwitchBList = window.document.getElementById("fastSwitchBList");
	var fastSwitchCList = window.document.getElementById("fastSwitchCList");
	var fastSwitchDList = window.document.getElementById("fastSwitchDList");
	
	fastSwitchAList.options.add(new Option("����1"));
	fastSwitchAList.options.add(new Option("����2"));
	fastSwitchAList.options.add(new Option("����3"));
	fastSwitchAList.options.add(new Option("����4"));
	fastSwitchAList.options.add(new Option("��ѡ"));
	fastSwitchAList.selectedIndex = 0;
	
	fastSwitchBList.options.add(new Option("����1"));
	fastSwitchBList.options.add(new Option("����2"));
	fastSwitchBList.options.add(new Option("����3"));
	fastSwitchBList.options.add(new Option("����4"));
	fastSwitchBList.options.add(new Option("��ѡ"));
	fastSwitchBList.selectedIndex = 1;
	
	fastSwitchCList.options.add(new Option("����1"));
	fastSwitchCList.options.add(new Option("����2"));
	fastSwitchCList.options.add(new Option("����3"));
	fastSwitchCList.options.add(new Option("����4"));
	fastSwitchCList.options.add(new Option("��ѡ"));
	fastSwitchCList.selectedIndex = 2;
	
	fastSwitchDList.options.add(new Option("����1"));
	fastSwitchDList.options.add(new Option("����2"));
	fastSwitchDList.options.add(new Option("����3"));
	fastSwitchDList.options.add(new Option("����4"));
	fastSwitchDList.options.add(new Option("��ѡ"));
	fastSwitchDList.selectedIndex = 3;
}

