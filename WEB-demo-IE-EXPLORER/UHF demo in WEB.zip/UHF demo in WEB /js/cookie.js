
//����������һ����cookie�����ӣ�һ����ֵ
function setCookie(name, value)
{
  var Days = 30;
  var exp = new Date();   
  exp.setTime(exp.getTime() + Days*24*60*60*1000);
  window.document.cookie = name + "="+ escape (value) + ";expires=" + exp.toGMTString();
}

//ȡcookies����
function getCookie(name)    
{
	var arr = window.document.cookie.match(new RegExp("(^| )"+name+"=([^;]*)(;|$)"));
	if(arr != null) return (arr[2]); return null;
}

//ɾ��cookie
function delCookie(name)
{
    var exp = new Date();
    exp.setTime(exp.getTime() - 1);
    var cval=getCookie(name);
    if(cval!=null) window.document.cookie= name + "="+cval+";expires="+exp.toGMTString();
}